import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, fontFamily} from '../theme';

const ink = C.ink;
const o = {stroke: ink, strokeWidth: 4, strokeLinejoin: 'round'} as const;
const Svg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill><svg viewBox="0 0 1080 1920" width={1080} height={1920} style={{display: 'block'}}>{children}</svg></AbsoluteFill>
);
const Planks: React.FC<{y: number; c: string}> = ({y, c}) => (
  <g stroke={c} strokeWidth={3}>{Array.from({length: 9}).map((_, i) => <line key={i} x1={i * 135} y1={y} x2={i * 135 - 60 + (i % 2) * 40} y2={1920} />)}
    {[y + 120, y + 260, y + 420].map((yy) => <line key={yy} x1={0} y1={yy} x2={1080} y2={yy} />)}</g>
);
const Win: React.FC<{x: number; y: number; w: number; h: number; sky?: string; night?: boolean}> = ({x, y, w, h, sky = '#BFE6FF', night}) => (
  <g>
    <rect x={x} y={y} width={w} height={h} rx={8} fill={night ? '#0E1635' : sky} {...o} />
    {night ? <><path d={`M${x + w * 0.62} ${y + 50} a30 30 0 1 0 28 40 a24 24 0 1 1 -28 -40Z`} fill="#FFF2B0" />{[[0.2, 0.25], [0.35, 0.6], [0.8, 0.7], [0.5, 0.2], [0.25, 0.85]].map(([a, b], i) => <circle key={i} cx={x + w * a} cy={y + h * b} r={3.5} fill="#fff" />)}</>
      : <><ellipse cx={x + w * 0.35} cy={y + h * 0.3} rx={50} ry={20} fill="#fff" /><circle cx={x + w * 0.78} cy={y + h * 0.25} r={28} fill="#FFD64A" /></>}
    <line x1={x + w / 2} y1={y} x2={x + w / 2} y2={y + h} {...o} /><line x1={x} y1={y + h / 2} x2={x + w} y2={y + h / 2} {...o} />
  </g>
);
const WallClock: React.FC<{x: number; y: number; r?: number; h?: number; m?: number}> = ({x, y, r = 80, h = 120, m = 0}) => (
  <g><circle cx={x} cy={y} r={r} fill="#fff" {...o} /><line x1={x} y1={y} x2={x} y2={y - r * 0.5} {...o} transform={`rotate(${h} ${x} ${y})`} /><line x1={x} y1={y} x2={x} y2={y - r * 0.75} {...o} strokeWidth={3} transform={`rotate(${m} ${x} ${y})`} /></g>
);

/** দিনের বৈঠকখানা — চাচার ঘর (জানালা, ঘড়ি, ছবি, সোফা) */
export const LivingRoom: React.FC = () => (
  <Svg>
    <rect width={1080} height={1380} fill="#F3E2C0" /><rect y={1380} width={1080} height={540} fill="#8B5E3C" /><Planks y={1380} c="#734a2c" /><rect y={1364} width={1080} height={18} fill="#6E4527" />
    <Win x={80} y={230} w={300} h={380} />
    <rect x={40} y={210} width={60} height={440} fill="#C4614B" {...o} /><rect x={360} y={210} width={60} height={440} fill="#C4614B" {...o} />
    <WallClock x={860} y={330} />
    <rect x={620} y={560} width={330} height={220} fill="#fff" {...o} /><rect x={640} y={580} width={290} height={180} fill="#9BC7A0" /><path d="M640 740 L720 650 L790 720 L850 660 L930 740Z" fill="#6FA076" />
    <rect x={60} y={1080} width={600} height={300} rx={40} fill="#A0522D" {...o} /><rect x={90} y={1020} width={540} height={150} rx={40} fill="#B8643A" {...o} />
  </Svg>
);

/** কাপড়ের দোকান */
export const ShopBg: React.FC = () => {
  const cols = ['#E0605A', '#4A90D9', '#F4C542', '#6CC24A', '#9B7FD1', '#F08A4B', '#5BC0BE'];
  return (
    <Svg>
      <rect width={1080} height={1400} fill="#EAD9BA" /><rect y={1400} width={1080} height={520} fill="#7B5B42" /><Planks y={1400} c="#634833" />
      {[430, 760, 1090].map((y, r) => (
        <g key={y}><rect x={40} y={y} width={1000} height={16} fill="#8B5E3C" {...o} />{cols.map((c, i) => <rect key={i} x={60 + i * 140} y={y - 120 + ((i + r) % 3) * 12} width={120} height={120 - ((i + r) % 3) * 12} rx={6} fill={cols[(i + r * 2) % 7]} {...o} />)}</g>
      ))}
      <rect x={290} y={150} width={500} height={110} rx={18} fill="#fff" {...o} /><text x={540} y={225} textAnchor="middle" fontSize={64} fontWeight={700} fontFamily={fontFamily} fill={ink}>কাপড়ের দোকান</text>
      <line x1={400} y1={60} x2={400} y2={150} {...o} /><line x1={680} y1={60} x2={680} y2={150} {...o} />
    </Svg>
  );
};

/** রাতের ঘর — রাকিবের বাড়ি */
export const NightRoom: React.FC = () => (
  <Svg>
    <rect width={1080} height={1380} fill="#1B2547" /><rect y={1380} width={1080} height={540} fill="#3A2E2B" /><Planks y={1380} c="#2c2220" /><rect y={1364} width={1080} height={18} fill="#2a2030" />
    <Win x={90} y={240} w={300} h={380} night />
    <WallClock x={860} y={330} h={355} m={330} />
    <rect x={640} y={620} width={300} height={200} fill="#2A355F" {...o} /><circle cx={790} cy={720} r={42} fill="#FFD27A" opacity={0.35} />
  </Svg>
);

/** দিনের ছোট ঘর / ওয়ার্করুম */
export const WorkRoom: React.FC = () => (
  <Svg>
    <rect width={1080} height={1380} fill="#F3E3C3" /><rect y={1380} width={1080} height={540} fill="#9A6B47" /><Planks y={1380} c="#7c5438" /><rect y={1364} width={1080} height={18} fill="#6E4527" />
    <Win x={640} y={230} w={300} h={380} />
    <rect x={610} y={210} width={50} height={420} fill="#D9694B" {...o} /><rect x={920} y={210} width={50} height={420} fill="#D9694B" {...o} />
    <rect x={70} y={560} width={420} height={16} fill="#8B5E3C" {...o} />{['#4A90D9', '#E0605A', '#F4C542', '#6CC24A'].map((c, i) => <rect key={i} x={90 + i * 95} y={470 + (i % 2) * 20} width={80} height={90 - (i % 2) * 20} fill={c} {...o} />)}
    <rect x={70} y={860} width={420} height={16} fill="#8B5E3C" {...o} /><rect x={110} y={770} width={150} height={90} fill="#C99A5B" {...o} /><rect x={300} y={790} width={130} height={70} fill="#D9B27A" {...o} />
  </Svg>
);

/** রাস্তা (দিন / সন্ধ্যা) */
export const StreetBg: React.FC<{tone?: 'day' | 'dusk'}> = ({tone = 'day'}) => {
  const dusk = tone === 'dusk';
  return (
    <Svg>
      <defs><linearGradient id="sk" x1={0} y1={0} x2={0} y2={1}><stop offset={0} stopColor={dusk ? '#F7B27A' : '#9FD8FF'} /><stop offset={1} stopColor={dusk ? '#FDE2B0' : '#E6F5FF'} /></linearGradient></defs>
      <rect width={1080} height={1400} fill="url(#sk)" /><circle cx={820} cy={dusk ? 760 : 420} r={dusk ? 130 : 90} fill="#FFD64A" opacity={0.95} />
      {[[40, 760, 260, '#D98B6A'], [330, 620, 300, '#C9B28F'], [660, 800, 380, '#B9856A']].map(([x, y, w, c], i) => (
        <g key={i}><rect x={x as number} y={y as number} width={w as number} height={1400 - (y as number)} fill={c as string} {...o} />{[0, 1, 2, 3].map((k) => <rect key={k} x={(x as number) + 40 + (k % 2) * 110} y={(y as number) + 60 + Math.floor(k / 2) * 130} width={70} height={90} fill="#FFF1B8" {...o} />)}</g>
      ))}
      <rect y={1380} width={1080} height={130} fill="#C9C2B6" {...o} /><rect y={1510} width={1080} height={410} fill="#5E6168" /><line x1={0} y1={1730} x2={1080} y2={1730} stroke="#fff" strokeWidth={10} strokeDasharray="70 50" />
    </Svg>
  );
};

/** ব্যাংকের সামনে */
export const BankBg: React.FC = () => (
  <Svg>
    <rect width={1080} height={1400} fill="#CDE8F7" /><rect y={1500} width={1080} height={420} fill="#7C7F86" /><rect y={1380} width={1080} height={140} fill="#C9C2B6" {...o} />
    <path d="M100 520 L540 300 L980 520Z" fill="#E7DCC4" {...o} /><rect x={140} y={520} width={800} height={60} fill="#D1C3A3" {...o} />
    <rect x={340} y={380} width={400} height={90} rx={14} fill="#1F4E8C" {...o} /><text x={540} y={448} textAnchor="middle" fontSize={62} fontWeight={700} fontFamily={fontFamily} fill="#fff">ব্যাংক</text>
    {[170, 360, 690, 810].map((x) => <rect key={x} x={x} y={580} width={90} height={800} fill="#F4EEDD" {...o} />)}
    <rect x={430} y={900} width={220} height={480} fill="#6B4A2F" {...o} /><line x1={540} y1={900} x2={540} y2={1380} {...o} />
    <rect x={120} y={1360} width={840} height={40} fill="#D1C3A3" {...o} />
  </Svg>
);

/** সন্ধ্যার চায়ের দোকান */
export const TeaBg: React.FC = () => (
  <Svg>
    <defs><linearGradient id="tk" x1={0} y1={0} x2={0} y2={1}><stop offset={0} stopColor="#F4A460" /><stop offset={1} stopColor="#FBD38D" /></linearGradient></defs>
    <rect width={1080} height={1400} fill="url(#tk)" /><circle cx={200} cy={620} r={110} fill="#FFE08A" opacity={0.9} /><rect y={1400} width={1080} height={520} fill="#6B5B4B" />
    <rect x={560} y={560} width={460} height={820} fill="#9A6B47" {...o} />
    {Array.from({length: 8}).map((_, i) => <rect key={i} x={540 + i * 62} y={520} width={62} height={120} fill={i % 2 ? '#fff' : C.red} {...o} />)}
    <rect x={600} y={680} width={150} height={90} rx={12} fill="#fff" {...o} /><text x={675} y={745} textAnchor="middle" fontSize={64} fontWeight={700} fontFamily={fontFamily} fill={ink}>চা</text>
    <rect x={560} y={1180} width={460} height={30} fill="#7a4a2a" {...o} /><path d="M640 1180 L650 1090 H730 L740 1180Z" fill="#B0B8C4" {...o} /><path d="M730 1110 h30 v30" fill="none" {...o} />
    <rect x={40} y={1300} width={420} height={26} fill="#7a4a2a" {...o} /><rect x={70} y={1326} width={20} height={80} fill="#7a4a2a" {...o} /><rect x={410} y={1326} width={20} height={80} fill="#7a4a2a" {...o} />
  </Svg>
);

/** আধুনিক অফিস */
export const OfficeBg: React.FC = () => (
  <Svg>
    <rect width={1080} height={1400} fill="#E9EEF5" /><rect y={1400} width={1080} height={520} fill="#5A6B7F" />
    <rect x={60} y={200} width={560} height={520} fill="#BFE6FF" {...o} />{[[90, 420, 90, 300], [210, 330, 110, 390], [350, 450, 100, 270], [480, 380, 110, 340]].map(([x, y, w, h], i) => <rect key={i} x={x} y={y} width={w} height={h} fill="#8FB1CC" {...o} />)}
    <line x1={340} y1={200} x2={340} y2={720} {...o} />
    <rect x={720} y={240} width={260} height={180} fill="#fff" {...o} /><rect x={740} y={260} width={220} height={140} fill="#F4E7C0" /><path d="M770 380 L830 310 L880 360 L920 320 L950 380Z" fill="#7FB38A" />
    <rect x={720} y={500} width={280} height={14} fill="#8B5E3C" {...o} />{['#4A90D9', '#E0605A', '#F4C542'].map((c, i) => <rect key={i} x={740 + i * 80} y={430 + (i % 2) * 20} width={60} height={70 - (i % 2) * 20} fill={c} {...o} />)}
    <rect x={900} y={1150} width={90} height={110} fill="#C4764B" {...o} /><path d="M945 1150 Q890 1080 920 1000 Q950 1070 945 1150 M945 1150 Q1000 1070 985 990 Q935 1070 945 1150" fill="#4C9A5E" {...o} />
    <rect y={1384} width={1080} height={18} fill="#44546a" />
  </Svg>
);

/** ক্লিন মোশন গ্রাফিক্স ব্যাকগ্রাউন্ড (সফট ভিনিয়েট) */
export const MGBg: React.FC<{tone?: 'warm' | 'dark'}> = ({tone = 'warm'}) => (
  <AbsoluteFill style={{background: tone === 'warm' ? 'radial-gradient(circle at 50% 42%, #FFF8E7 0%, #F6E7C1 62%, #E3CD97 100%)' : 'radial-gradient(circle at 50% 42%, #2B3A6B 0%, #1B2547 62%, #0E1530 100%)'}} />
);

/** টেবিল / কাউন্টার — ক্যারেক্টারের পরে আঁকলে সামনে পড়ে */
export const Table: React.FC<{x: number; w: number; top?: number; color?: string}> = ({x, w, top = 1310, color = '#8B5E3C'}) => (
  <Svg>
    <rect x={x} y={top} width={w} height={28} rx={6} fill={color} {...o} /><rect x={x + 14} y={top + 28} width={w - 28} height={60} fill="#7a4f31" {...o} />
    <rect x={x + 24} y={top + 88} width={26} height={230} fill={color} {...o} /><rect x={x + w - 50} y={top + 88} width={26} height={230} fill={color} {...o} />
  </Svg>
);

/** অফিস ডেস্ক (ড্রয়ারসহ) — drawerAt সেকেন্ডে ড্রয়ার খোলে */
export const Desk: React.FC<{drawerAt?: number}> = ({drawerAt}) => {
  const t = useCurrentFrame() / 30;
  const open = drawerAt !== undefined && t >= drawerAt ? Math.min(1, (t - drawerAt) / 0.3) : 0;
  return (
    <Svg>
      <rect x={30} y={1330} width={1020} height={34} rx={8} fill="#8B5E3C" {...o} /><rect x={50} y={1364} width={980} height={230} fill="#A56F45" {...o} />
      <rect x={70} y={1390 + open * 30} width={300} height={90} rx={8} fill="#B98353" {...o} /><rect x={190} y={1428 + open * 30} width={60} height={10} rx={5} fill="#5b3a22" />
      <rect x={720} y={1390} width={280} height={90} rx={8} fill="#B98353" {...o} />
    </Svg>
  );
};
