import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {C, FPS} from '../theme';

export type Mood = 'neutral' | 'happy' | 'sad' | 'angry' | 'surprised' | 'worried' | 'cry' | 'think' | 'sleep' | 'determined';
export type Pose = {l: number; r: number};
export const P: Record<string, Pose> = {
  idle: {l: 7, r: -7}, hold: {l: -32, r: 32}, point: {l: 7, r: -100}, pointL: {l: 100, r: -7}, up: {l: 7, r: -155},
  salute: {l: 7, r: -158}, both: {l: 150, r: -150}, cross: {l: -55, r: 55}, give: {l: 7, r: -70}, take: {l: 70, r: -7}, work: {l: -30, r: 30},
};

export type Look = {
  skin: string; hair: 'spiky' | 'short' | 'topi' | 'hijab' | 'none'; hairColor: string; body: 'shirt' | 'tshirt' | 'panjabi' | 'saree';
  top: string; pants: string; shoes?: string; glasses?: boolean; beard?: boolean; pocket?: boolean; tie?: boolean; browC?: string;
};

const rakib: Look = {skin: '#B9774A', hair: 'spiky', hairColor: '#2a2018', body: 'shirt', top: '#8EC5F0', pants: '#7B7F86', pocket: true};
export const CAST: Record<string, Look> = {
  rakib,
  rakib2: {...rakib, tie: true, pants: '#4a5468'},
  jamal: {skin: '#C58A5E', hair: 'topi', hairColor: '#F4F1E8', body: 'panjabi', top: '#8B5A3C', pants: '#F5F5F0', beard: true, glasses: true, browC: '#8a8a8a'},
  ma: {skin: '#C58A5E', hair: 'hijab', hairColor: '#2E9E5B', body: 'saree', top: '#2E9E5B', pants: '#2E9E5B'},
  fahim: {skin: '#B9774A', hair: 'short', hairColor: '#3b2a20', body: 'tshirt', top: '#555B66', pants: '#2F4B7C'},
};
// নামহীন এক্সট্রা (e0..e9)
const SK = ['#B9774A', '#C58A5E', '#D49A6A', '#A86A40'];
const TP = ['#E0605A', '#F4C542', '#6CC24A', '#9B7FD1', '#4A90D9', '#F08A4B', '#5BC0BE', '#D96AA7', '#8E99A8', '#E8E1CF'];
for (let i = 0; i < 10; i++) {
  CAST['e' + i] = {skin: SK[i % 4], hair: i % 3 === 0 ? 'spiky' : i % 3 === 1 ? 'short' : 'hijab', hairColor: i % 3 === 2 ? TP[(i + 3) % 10] : '#2a2018',
    body: i % 3 === 2 ? 'saree' : i % 2 ? 'shirt' : 'tshirt', top: i % 3 === 2 ? TP[(i + 3) % 10] : TP[i], pants: i % 3 === 2 ? TP[(i + 3) % 10] : '#3d4660'};
}

type KF<T> = {t: number; v: T}[];
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
function curPose(base: Pose, kfs: {t: number; p: Pose}[] | undefined, t: number): Pose {
  if (!kfs) return base;
  let i = -1;
  kfs.forEach((k, j) => { if (k.t <= t) i = j; });
  if (i < 0) return base;
  const prev = i > 0 ? kfs[i - 1].p : base;
  const k = Math.min(1, (t - kfs[i].t) / 0.3);
  const e = 1 - (1 - k) * (1 - k);
  return {l: lerp(prev.l, kfs[i].p.l, e), r: lerp(prev.r, kfs[i].p.r, e)};
}

export const Char: React.FC<{
  who: string; x?: number; y: number; s?: number; mood?: Mood; moods?: {t: number; m: Mood}[]; pose?: Pose; poses?: {t: number; p: Pose}[];
  talk?: [number, number][]; lHand?: React.ReactNode; rHand?: React.ReactNode; tremble?: number; look?: number; float?: number; seed?: number;
  walk?: {x0: number; x1: number; t0: number; t1: number}; sit?: boolean; pocketPaperAt?: number;
}> = (p) => {
  const f = useCurrentFrame();
  const t = f / FPS;
  const L = CAST[p.who];
  const s = p.s ?? 2.2;
  const sw = 2.3 / s;
  const seed = p.seed ?? 0;
  let mood: Mood = p.mood ?? 'neutral';
  (p.moods ?? []).forEach((k) => { if (k.t <= t) mood = k.m; });
  const pose = curPose(p.pose ?? P.idle, p.poses, t);
  const walking = !!p.walk && t >= p.walk.t0 && t <= p.walk.t1;
  const X = p.walk ? interpolate(t, [p.walk.t0, p.walk.t1], [p.walk.x0, p.walk.x1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : (p.x ?? 540);
  const bob = walking ? -Math.abs(Math.sin(f * 0.22)) * 14 : Math.sin((f + seed * 20) / 16) * (p.float ?? 5);
  const leg = walking ? Math.sin(f * 0.22) * 24 : 0;
  const tr = p.tremble ?? 0;
  const dx = Math.sin(f * 3.7) * tr;
  const dy = Math.cos(f * 4.3) * tr * 0.6;
  const talking = (p.talk ?? []).some(([a, b]) => t >= a && t < b);
  const mo = [0, 1, 2, 1, 0, 2, 1, 2][Math.floor(f / 3 + seed) % 8];
  const blink = (f + seed * 17) % 100 < 4;
  const look = p.look ?? 0;
  const st = {stroke: C.ink, strokeWidth: sw, strokeLinejoin: 'round', strokeLinecap: 'round'} as const;
  const mouthFill = '#7a2230';

  const BR: Record<Mood, [number, number]> = {neutral: [0, 0], happy: [0, -4], sad: [-16, 0], angry: [18, 5], surprised: [0, -12], worried: [-12, -2], cry: [-18, 0], think: [-6, -3], sleep: [0, 2], determined: [10, 3]};
  const [ba, bdy] = BR[mood];
  const MP: Record<Mood, string> = {
    neutral: 'M88 114 L112 114', happy: 'M84 108 Q100 130 116 108Z', sad: 'M88 118 Q100 106 112 118', angry: 'M88 118 Q100 110 112 118', surprised: '',
    worried: 'M87 116 Q93 111 100 116 T113 116', cry: 'M86 122 Q100 104 114 122Z', think: 'M92 116 L112 112', sleep: 'M92 114 Q100 119 108 114', determined: 'M90 115 L110 115',
  };

  const arm = (sx: number, ang: number, hand?: React.ReactNode) => (
    <g transform={`translate(${sx} 160) rotate(${ang})`}>
      <rect x={-11} y={-6} width={22} height={94} rx={11} fill={L.skin} {...st} />
      <rect x={-11} y={-6} width={22} height={L.body === 'tshirt' ? 34 : 78} rx={11} fill={L.top} {...st} />
      <circle cx={0} cy={90} r={12} fill={L.skin} {...st} />
      {hand && <g transform="translate(0 90)">{hand}</g>}
    </g>
  );
  const eye = (cx: number) =>
    mood === 'sleep' ? (
      <path d={`M${cx - 11} 86 Q${cx} 95 ${cx + 11} 86`} fill="none" {...st} />
    ) : (
      <g transform={`translate(${cx} 84) scale(1 ${blink ? 0.12 : 1})`}>
        <ellipse rx={11} ry={12} fill="#fff" {...st} />
        <circle cx={look} cy={mood === 'sad' || mood === 'cry' ? 2 : 0} r={mood === 'surprised' ? 4 : 6} fill={C.ink} />
        <circle cx={look + 2} cy={-2} r={1.8} fill="#fff" />
      </g>
    );
  const brow = (cx: number, sgn: number) => (
    <path d="M-13 0 Q0 -5 13 0" transform={`translate(${cx} ${64 + bdy}) rotate(${sgn * ba})`} fill="none" stroke={L.browC ?? C.ink} strokeWidth={sw * 2.2} strokeLinecap="round" />
  );
  const mouth = () => {
    if (talking) {
      if (mo === 0) return <path d={mood === 'happy' ? MP.happy : 'M88 114 L112 114'} fill={mood === 'happy' ? mouthFill : 'none'} {...st} />;
      return <ellipse cx={100} cy={115} rx={mo === 1 ? 8 : 10} ry={mo === 1 ? 4 : 9} fill={mouthFill} {...st} />;
    }
    if (mood === 'surprised') return <ellipse cx={100} cy={116} rx={6} ry={9} fill={mouthFill} {...st} />;
    const filled = mood === 'happy' || mood === 'cry';
    return <path d={MP[mood]} fill={filled ? mouthFill : 'none'} {...st} />;
  };

  // মাথা
  const hijab = L.hair === 'hijab';
  const head = (
    <g>
      {hijab && <path d="M38 96 Q28 10 100 12 Q172 10 162 96 Q164 156 130 172 L70 172 Q36 156 38 96Z" fill={L.hairColor} {...st} />}
      <rect x={90} y={118} width={20} height={26} fill={L.skin} {...st} />
      {!hijab && <><circle cx={54} cy={90} r={8} fill={L.skin} {...st} /><circle cx={146} cy={90} r={8} fill={L.skin} {...st} /></>}
      <ellipse cx={100} cy={hijab ? 88 : 85} rx={hijab ? 40 : 46} ry={hijab ? 46 : 50} fill={L.skin} {...st} />
      {L.hair === 'spiky' && <path d="M55 74 Q52 32 78 38 L84 12 L98 34 L112 8 L120 36 L142 20 Q152 44 145 74 Q130 54 100 54 Q72 54 55 74Z" fill={L.hairColor} {...st} />}
      {L.hair === 'short' && <path d="M54 78 Q46 30 100 30 Q154 30 146 78 Q136 56 112 54 Q84 60 70 56 Q58 62 54 78Z" fill={L.hairColor} {...st} />}
      {L.hair === 'topi' && <><path d="M56 64 Q58 20 100 20 Q142 20 144 64 Q100 52 56 64Z" fill={L.hairColor} {...st} /><path d="M62 52 Q100 40 138 52" fill="none" stroke="#C9C2AE" strokeWidth={sw} /></>}
      {hijab && <path d="M58 72 Q100 20 142 72 Q100 46 58 72Z" fill={L.hairColor} {...st} />}
      {L.beard && <path d="M56 96 Q58 150 100 158 Q142 150 144 96 Q128 122 100 120 Q72 122 56 96Z" fill="#EFEFEF" {...st} />}
      {(mood === 'happy' || p.who === 'ma') && mood !== 'sad' && mood !== 'cry' && <><circle cx={66} cy={102} r={6} fill="#F08A7E" opacity={0.45} /><circle cx={134} cy={102} r={6} fill="#F08A7E" opacity={0.45} /></>}
      {eye(80)}{eye(120)}
      {brow(80, 1)}{brow(120, -1)}
      {L.glasses && <g fill="none" {...st}><circle cx={80} cy={84} r={16} /><circle cx={120} cy={84} r={16} /><path d="M96 84 Q100 80 104 84" /></g>}
      <path d="M100 92 Q96 101 102 101" fill="none" stroke={C.ink} strokeWidth={sw} strokeLinecap="round" />
      {mouth()}
      {mood === 'cry' && [72, 128].map((cx, i) => {
        const k = (f + i * 9) % 30;
        return <ellipse key={i} cx={cx} cy={100 + k * 1.6} rx={4} ry={6} fill="#5BB6F0" opacity={1 - k / 34} />;
      })}
    </g>
  );

  // শরীর + পা
  const sit = !!p.sit;
  const legs = L.body === 'saree' ? (
    <g>
      <path d="M60 250 L140 250 L154 380 L46 380Z" fill={L.top} {...st} />
      <path d="M62 300 Q100 312 138 300" fill="none" stroke="#1F7A45" strokeWidth={sw * 1.4} />
      <ellipse cx={80} cy={386} rx={17} ry={8} fill="#6b4a2f" {...st} /><ellipse cx={120} cy={386} rx={17} ry={8} fill="#6b4a2f" {...st} />
    </g>
  ) : (
    [82, 118].map((hx, i) => (
      <g key={hx} transform={`translate(${hx} 250) rotate(${(i ? -1 : 1) * (sit ? 88 : leg)})`}>
        <rect x={-12} y={0} width={24} height={132} rx={12} fill={L.pants} {...st} />
        <ellipse cx={0} cy={134} rx={17} ry={9} fill={L.shoes ?? '#2b2b2b'} {...st} />
      </g>
    ))
  );
  const bodyH = L.body === 'panjabi' ? 178 : 130;
  const body = (
    <g>
      <rect x={52} y={138} width={96} height={bodyH} rx={30} fill={L.top} {...st} />
      {(L.body === 'shirt' || L.body === 'tshirt') && <path d="M82 138 L100 158 L118 138Z" fill="#fff" {...st} />}
      {L.body === 'panjabi' && <><path d="M100 140 V210" fill="none" {...st} />{[160, 178, 196].map((y) => <circle key={y} cx={100} cy={y} r={2.5} fill="#EFE6D0" />)}<path d="M52 300 V316 M148 300 V316" fill="none" {...st} /></>}
      {L.body === 'saree' && <path d="M52 158 L148 232 L148 262 L52 190Z" fill="#1F7A45" {...st} />}
      {L.pocket && <rect x={112} y={166} width={20} height={22} rx={3} fill="none" {...st} />}
      {L.tie && <path d="M100 158 L93 175 L100 215 L107 175Z" fill="#C0392B" {...st} />}
      {p.pocketPaperAt !== undefined && t >= p.pocketPaperAt && <path d="M115 168 L118 154 L129 156 L128 170Z" fill="#fff" {...st} />}
    </g>
  );

  return (
    <div style={{position: 'absolute', left: X - 100 * s + dx, top: GROUNDY(p.y, s, sit) + bob + dy, width: 200 * s, height: 400 * s}}>
      <svg viewBox="0 0 200 400" width={200 * s} height={400 * s} style={{overflow: 'visible', display: 'block'}}>
        {legs}{body}
        {arm(54, pose.l, p.lHand)}{arm(146, pose.r, p.rHand)}
        {head}
      </svg>
    </div>
  );
};

const GROUNDY = (y: number, s: number, sit: boolean) => y - 400 * s + (sit ? 125 * s : 0);
