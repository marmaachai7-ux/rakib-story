import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, fontFamily} from '../theme';

const st = {stroke: C.ink, strokeWidth: 3, strokeLinejoin: 'round', strokeLinecap: 'round'} as const;
const nf = {fill: 'none'} as const;

export type IconName =
  | 'taka' | 'note' | 'clock' | 'calendar' | 'phone' | 'tin' | 'tinopen' | 'paper' | 'paperfold' | 'notebook' | 'envelope' | 'box' | 'broken'
  | 'bank' | 'heart' | 'question' | 'bulb' | 'check' | 'cross' | 'bike' | 'page' | 'van' | 'spoon' | 'knife' | 'pot' | 'basket' | 'pill'
  | 'house' | 'bell' | 'person' | 'plate' | 'play' | 'sun' | 'zzz' | 'cup' | 'cloth' | 'refund' | 'news' | 'bag';

/** ১০০×১০০ বক্সে আঁকা আইকনের <g> — ক্যারেক্টারের হাতেও বসানো যায় */
export const IconG: React.FC<{name: IconName; label?: string; color?: string}> = ({name, label, color}) => {
  const f = useCurrentFrame();
  switch (name) {
    case 'taka':
      return (<g><circle cx={50} cy={50} r={40} fill="#FFC93C" {...st} /><circle cx={50} cy={50} r={30} {...nf} {...st} strokeWidth={2} />
        <text x={50} y={66} textAnchor="middle" fontSize={46} fontWeight={700} fontFamily={fontFamily} fill={C.ink}>৳</text></g>);
    case 'note':
      return (<g><rect x={6} y={26} width={88} height={48} rx={7} fill="#7CC576" {...st} /><circle cx={50} cy={50} r={15} fill="#A8DDA2" {...st} strokeWidth={2} />
        <text x={50} y={58} textAnchor="middle" fontSize={label ? 20 : 22} fontWeight={700} fontFamily={fontFamily} fill={C.ink}>{label ?? '৳'}</text></g>);
    case 'clock':
      return (<g><circle cx={50} cy={50} r={40} fill="#fff" {...st} />{[0, 90, 180, 270].map((a) => <line key={a} x1={50} y1={14} x2={50} y2={20} {...st} transform={`rotate(${a} 50 50)`} />)}
        <line x1={50} y1={50} x2={50} y2={26} {...st} transform={`rotate(${f * 6} 50 50)`} /><line x1={50} y1={50} x2={50} y2={34} {...st} transform={`rotate(${f * 0.5} 50 50)`} strokeWidth={4} /></g>);
    case 'calendar': {
      const n = Math.min(12, Math.floor(f / 5));
      return (<g><rect x={10} y={14} width={80} height={76} rx={8} fill="#fff" {...st} /><path d="M10 40 V22 a8 8 0 0 1 8 -8 H82 a8 8 0 0 1 8 8 V40Z" fill={C.red} {...st} />
        {Array.from({length: 12}).map((_, i) => {
          const cx = 24 + (i % 4) * 17; const cy = 54 + Math.floor(i / 4) * 12;
          return (<g key={i}><rect x={cx - 6} y={cy - 5} width={12} height={10} fill="#eee" />{i < n && <path d={`M${cx - 5} ${cy - 5} L${cx + 5} ${cy + 5} M${cx + 5} ${cy - 5} L${cx - 5} ${cy + 5}`} stroke={C.red} strokeWidth={2.5} />}</g>);
        })}</g>);
    }
    case 'phone': {
      const ring = Math.sin(f / 2) * 6;
      return (<g transform={`rotate(${ring} 50 50)`}><rect x={28} y={6} width={44} height={88} rx={9} fill="#2b2f3a" {...st} /><rect x={33} y={15} width={34} height={64} rx={3} fill="#BFE6FF" />
        <circle cx={50} cy={86} r={3} fill="#888" />{label === 'ring' && <><path d="M12 28 Q6 50 12 72" {...nf} {...st} /><path d="M88 28 Q94 50 88 72" {...nf} {...st} /><path d="M4 36 Q-2 50 4 64" {...nf} {...st} /><path d="M96 36 Q102 50 96 64" {...nf} {...st} /></>}</g>);
    }
    case 'tin':
    case 'tinopen':
      return (<g><rect x={22} y={34} width={56} height={52} rx={4} fill="#fff" {...st} /><rect x={22} y={50} width={56} height={22} fill={C.red} {...st} />
        {name === 'tin' ? <ellipse cx={50} cy={32} rx={31} ry={8} fill="#D64545" {...st} /> : <><ellipse cx={50} cy={34} rx={28} ry={6} fill="#444" {...st} /><ellipse cx={72} cy={14} rx={30} ry={6} fill="#D64545" {...st} transform="rotate(-25 72 14)" /></>}</g>);
    case 'paper':
      return (<g><rect x={20} y={8} width={60} height={84} rx={4} fill="#fff" {...st} />{[26, 38, 50, 62, 74].map((y) => <line key={y} x1={30} y1={y} x2={y === 74 ? 54 : 70} y2={y} stroke="#5B7BD5" strokeWidth={3} strokeLinecap="round" />)}</g>);
    case 'paperfold':
      return (<g><rect x={22} y={26} width={56} height={48} rx={3} fill="#F4E7C0" {...st} /><path d="M22 50 H78" {...nf} {...st} strokeWidth={2} /><path d="M70 26 L78 34" {...nf} {...st} strokeWidth={2} /></g>);
    case 'notebook':
      return (<g><rect x={12} y={14} width={76} height={72} rx={5} fill="#F8F2D8" {...st} /><line x1={50} y1={14} x2={50} y2={86} {...st} />
        {[34, 46, 58, 70].map((y) => <g key={y}><line x1={20} y1={y} x2={44} y2={y} stroke="#999" strokeWidth={2} /><line x1={57} y1={y} x2={y === 70 ? 74 : 80} y2={y} stroke="#5B7BD5" strokeWidth={3} strokeLinecap="round" /></g>)}</g>);
    case 'envelope':
      return (<g><rect x={8} y={24} width={84} height={54} rx={5} fill="#F7EBC9" {...st} /><path d="M8 28 L50 56 L92 28" {...nf} {...st} /><circle cx={50} cy={62} r={9} fill="#FFC93C" {...st} strokeWidth={2} /></g>);
    case 'box':
    case 'broken':
      return (<g><path d="M10 32 L50 14 L90 32 V72 L50 90 L10 72Z" fill="#C99A5B" {...st} /><path d="M10 32 L50 50 L90 32 M50 50 V90" {...nf} {...st} /><path d="M32 23 L72 41" stroke="#F4E7C0" strokeWidth={8} />
        {name === 'broken' && <><path d="M58 52 L66 62 L58 70 L68 82" {...nf} stroke={C.red} strokeWidth={4} /><path d="M80 20 L92 8 M84 30 L98 28" {...nf} {...st} /></>}</g>);
    case 'bank':
      return (<g><path d="M8 38 L50 12 L92 38Z" fill="#E7DCC4" {...st} /><rect x={12} y={38} width={76} height={8} fill="#D1C3A3" {...st} />{[22, 40, 58, 74].map((x) => <rect key={x} x={x} y={48} width={8} height={30} fill="#fff" {...st} />)}<rect x={8} y={80} width={84} height={10} fill="#D1C3A3" {...st} /></g>);
    case 'heart':
      return <path d="M50 86 C10 58 6 28 28 20 C40 16 48 24 50 32 C52 24 60 16 72 20 C94 28 90 58 50 86Z" fill="#F0506E" {...st} />;
    case 'question':
      return (<g><circle cx={50} cy={50} r={40} fill="#FFD23F" {...st} /><text x={50} y={68} textAnchor="middle" fontSize={58} fontWeight={700} fontFamily={fontFamily} fill={C.ink}>?</text></g>);
    case 'bulb':
      return (<g><path d="M50 8 C28 8 20 28 28 44 C34 54 36 58 36 66 H64 C64 58 66 54 72 44 C80 28 72 8 50 8Z" fill="#FFE066" {...st} /><rect x={38} y={66} width={24} height={8} rx={2} fill="#bbb" {...st} /><rect x={42} y={76} width={16} height={8} rx={3} fill="#999" {...st} />
        {[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([a, b], i) => <line key={i} x1={50 + a * 44} y1={30 + b * 14} x2={50 + a * 52} y2={30 + b * 18} {...st} />)}</g>);
    case 'check':
      return (<g><circle cx={50} cy={50} r={40} fill="#4CAF6A" {...st} /><path d="M28 52 L44 68 L74 34" {...nf} stroke="#fff" strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" /></g>);
    case 'cross':
      return (<g><circle cx={50} cy={50} r={40} fill={C.red} {...st} /><path d="M32 32 L68 68 M68 32 L32 68" {...nf} stroke="#fff" strokeWidth={9} strokeLinecap="round" /></g>);
    case 'bike':
      return (<g><circle cx={24} cy={66} r={19} {...nf} {...st} strokeWidth={4} /><circle cx={76} cy={66} r={19} {...nf} {...st} strokeWidth={4} /><path d="M24 66 L42 36 H62 L76 66 M42 36 L52 66 H24 M36 28 H48 M60 28 H70 L62 36" {...nf} {...st} strokeWidth={4} stroke="#2a6fb8" /></g>);
    case 'page':
      return (<g><rect x={8} y={8} width={84} height={84} rx={20} fill="#3B6FD8" {...st} /><text x={55} y={86} textAnchor="middle" fontSize={84} fontWeight={700} fontFamily="Arial, sans-serif" fill="#fff">f</text></g>);
    case 'van':
      return (<g><rect x={4} y={26} width={58} height={44} rx={5} fill="#fff" {...st} /><path d="M62 38 H80 L94 52 V70 H62Z" fill="#F4C542" {...st} /><circle cx={24} cy={72} r={10} fill="#444" {...st} /><circle cx={78} cy={72} r={10} fill="#444" {...st} /><rect x={14} y={36} width={34} height={8} fill="#D64545" /></g>);
    case 'spoon':
      return (<g transform="rotate(35 50 50)"><ellipse cx={50} cy={26} rx={17} ry={22} fill="#C58A4F" {...st} /><rect x={45} y={44} width={10} height={48} rx={5} fill="#C58A4F" {...st} /></g>);
    case 'knife':
      return (<g transform="rotate(-30 50 50)"><path d="M44 8 H58 Q66 40 56 64 H44Z" fill="#D8DEE6" {...st} /><rect x={42} y={62} width={18} height={32} rx={5} fill="#7a4a2a" {...st} /></g>);
    case 'pot':
      return (<g><path d="M14 40 H86 L80 82 Q78 88 72 88 H28 Q22 88 20 82Z" fill="#8E99A8" {...st} /><rect x={10} y={34} width={80} height={8} rx={4} fill="#6E7888" {...st} /><path d="M86 48 H98 M14 48 H2" {...nf} {...st} strokeWidth={5} /><path d="M40 24 Q44 14 40 6 M58 24 Q62 14 58 6" {...nf} stroke="#bbb" strokeWidth={3} strokeLinecap="round" /></g>);
    case 'basket':
      return (<g><path d="M10 40 H90 L80 84 H20Z" fill="#D9A55B" {...st} /><path d="M26 40 Q50 -4 74 40" {...nf} {...st} strokeWidth={4} /><circle cx={38} cy={36} r={9} fill="#E5533D" {...st} /><circle cx={58} cy={34} r={9} fill="#6CC24A" {...st} /></g>);
    case 'pill':
      return (<g transform="rotate(-35 50 50)"><rect x={14} y={30} width={72} height={40} rx={20} fill="#fff" {...st} /><path d="M50 30 H66 a20 20 0 0 1 0 40 H50Z" fill="#F0506E" {...st} /></g>);
    case 'house':
      return (<g><path d="M8 50 L50 14 L92 50Z" fill="#D9694B" {...st} /><rect x={18} y={50} width={64} height={40} fill="#F4E7C0" {...st} /><rect x={42} y={62} width={16} height={28} fill="#8B5A3C" {...st} /></g>);
    case 'bell':
      return (<g><path d="M50 10 C28 10 26 34 24 50 L16 72 H84 L76 50 C74 34 72 10 50 10Z" fill="#FFC93C" {...st} /><circle cx={50} cy={80} r={8} fill="#E0A21B" {...st} /><circle cx={78} cy={22} r={12} fill={C.red} {...st} /></g>);
    case 'person':
      return (<g><circle cx={50} cy={32} r={20} fill={color ?? '#E7B98C'} {...st} /><path d="M12 92 C12 62 30 56 50 56 C70 56 88 62 88 92Z" fill={color ? color : '#6C9BD8'} {...st} /></g>);
    case 'plate':
      return (<g><ellipse cx={50} cy={62} rx={46} ry={16} fill="#fff" {...st} /><ellipse cx={50} cy={58} rx={30} ry={9} fill="#F8F8F0" {...st} strokeWidth={2} /><path d="M26 56 Q50 22 74 56Z" fill="#fff" {...st} /><path d="M40 42 q2 -8 0 -14 M54 40 q2 -8 0 -14" {...nf} stroke="#bbb" strokeWidth={3} strokeLinecap="round" /></g>);
    case 'play':
      return (<g><rect x={6} y={22} width={88} height={56} rx={12} fill="#E04040" {...st} /><path d="M42 36 L66 50 L42 64Z" fill="#fff" /></g>);
    case 'sun':
      return (<g><circle cx={50} cy={50} r={22} fill="#FFC93C" {...st} />{Array.from({length: 8}).map((_, i) => <line key={i} x1={50} y1={14} x2={50} y2={4} {...st} transform={`rotate(${i * 45 + f} 50 50)`} />)}</g>);
    case 'zzz':
      return (<g fontFamily="Arial, sans-serif" fontWeight={700} fill="#fff" stroke={C.ink} strokeWidth={1.5}><text x={10} y={84} fontSize={40}>Z</text><text x={34} y={56} fontSize={34}>z</text><text x={58} y={34} fontSize={28}>z</text></g>);
    case 'cup':
      return (<g><path d="M18 34 H72 V62 Q72 82 45 82 Q18 82 18 62Z" fill="#fff" {...st} /><path d="M72 40 H82 Q90 40 90 50 Q90 60 76 60" {...nf} {...st} /><ellipse cx={45} cy={34} rx={27} ry={5} fill="#B9772F" {...st} /><path d="M34 22 q3 -7 0 -14 M52 22 q3 -7 0 -14" {...nf} stroke="#bbb" strokeWidth={3} strokeLinecap="round" /></g>);
    case 'cloth':
      return (<g>{['#E0605A', '#4A90D9', '#F4C542', '#6CC24A'].map((c, i) => <rect key={i} x={12 + (i % 2) * 6} y={14 + i * 18} width={76} height={18} rx={4} fill={c} {...st} />)}</g>);
    case 'refund':
      return (<g><circle cx={50} cy={50} r={40} fill="#FFC93C" {...st} /><text x={50} y={64} textAnchor="middle" fontSize={40} fontWeight={700} fontFamily={fontFamily} fill={C.ink}>৳</text><path d="M20 30 A36 36 0 0 1 78 26 M78 26 L80 12 M78 26 L64 26" {...nf} stroke={C.red} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" /></g>);
    case 'news':
      return (<g><rect x={10} y={16} width={80} height={68} rx={4} fill="#EDE8DA" {...st} /><rect x={18} y={24} width={64} height={12} fill="#555" />{[44, 54, 64, 74].map((y) => <line key={y} x1={18} y1={y} x2={82} y2={y} stroke="#999" strokeWidth={3} />)}</g>);
    case 'bag':
      return (<g><rect x={14} y={30} width={72} height={58} rx={6} fill="#F08A4B" {...st} /><path d="M34 36 V24 a16 16 0 0 1 32 0 V36" {...nf} {...st} /></g>);
    default:
      return null;
  }
};

export const Icon: React.FC<{name: IconName; size?: number; label?: string; color?: string}> = ({name, size = 160, label, color}) => (
  <svg viewBox="0 0 100 100" width={size} height={size} style={{overflow: 'visible', display: 'block'}}><IconG name={name} label={label} color={color} /></svg>
);

/** ক্যারেক্টারের হাতে ধরা প্রপ (১ ইউনিট = ১ viewBox ইউনিট) */
export const HandIcon: React.FC<{name: IconName; size?: number}> = ({name, size = 40}) => (
  <g transform={`translate(${-size / 2} ${-size / 2 + 6}) scale(${size / 100})`}><IconG name={name} /></g>
);
