import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {Pop, clamp, useSec} from '../lib/At';
import {C, fontFamily} from '../theme';
import {MGBg} from './Backgrounds';
import {Icon, IconName} from './Icons';

const bd = `5px solid ${C.ink}`;

/** ধাপে ধাপে ফ্লো ডায়াগ্রাম (উপর→নিচ). steps[].at = শটের লোকাল সেকেন্ড */
export const Flow: React.FC<{title: string; steps: {icon: IconName; label: string; at: number}[]}> = ({title, steps}) => (
  <>
    <MGBg />
    <Pop x={540} y={250} at={0}>
      <div style={{background: C.yellow, border: bd, borderRadius: 60, padding: '12px 50px', fontFamily, fontWeight: 700, fontSize: 60, color: C.ink, whiteSpace: 'nowrap'}}>{title}</div>
    </Pop>
    {steps.map((s, i) => (
      <React.Fragment key={i}>
        <Pop x={540} y={560 + i * 380} at={s.at}>
          <div style={{width: 860, height: 250, background: '#fff', border: bd, borderRadius: 40, display: 'flex', alignItems: 'center', gap: 36, padding: '0 50px', boxShadow: '8px 10px 0 rgba(0,0,0,.18)'}}>
            <Icon name={s.icon} size={170} />
            <div style={{fontFamily, fontWeight: 700, fontSize: 62, color: C.ink, lineHeight: 1.2}}>{s.label}</div>
          </div>
        </Pop>
        {i < steps.length - 1 && (
          <Pop x={540} y={560 + i * 380 + 190} at={steps[i + 1].at - 0.25}>
            <svg width={90} height={110} viewBox="0 0 90 110"><path d="M45 6 V76 M16 54 L45 90 L74 54" fill="none" stroke={C.ink} strokeWidth={12} strokeLinecap="round" strokeLinejoin="round" /></svg>
          </Pop>
        )}
      </React.Fragment>
    ))}
  </>
);

/** মুখে মুখে ছড়ানো ক্রেতার নেটওয়ার্ক (টেক্সট ছাড়া) */
export const Network: React.FC = () => {
  const cx = 540, cy = 900;
  const ring1 = [-90, 30, 150].map((a, i) => ({a, r: 270, at: 0.5 + i * 0.5}));
  const ring2 = [-115, -65, 5, 55, 125, 175].map((a, i) => ({a, r: 470, at: 2.2 + i * 0.35}));
  const pos = (a: number, r: number) => [cx + Math.cos((a * Math.PI) / 180) * r * 0.95, cy + Math.sin((a * Math.PI) / 180) * r * 1.2];
  const f = useCurrentFrame();
  return (
    <>
      <MGBg />
      <svg viewBox="0 0 1080 1920" width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
        {ring1.map((n, i) => { const [x, y] = pos(n.a, n.r); return f / 30 > n.at && <line key={i} x1={cx} y1={cy} x2={x} y2={y} stroke={C.ink} strokeWidth={5} strokeDasharray="14 10" />; })}
        {ring2.map((n, i) => { const [x, y] = pos(n.a, n.r); const [px, py] = pos(ring1[Math.floor(i / 2)].a, 270); return f / 30 > n.at && <line key={i} x1={px} y1={py} x2={x} y2={y} stroke={C.ink} strokeWidth={4} strokeDasharray="12 10" />; })}
      </svg>
      <Pop x={cx} y={cy} at={0} pulse><Icon name="page" size={250} /></Pop>
      {ring1.map((n, i) => { const [x, y] = pos(n.a, n.r); return <Pop key={i} x={x} y={y} at={n.at}><Icon name="person" size={150} color={['#E7B98C', '#C58A5E', '#D49A6A'][i]} /></Pop>; })}
      {ring1.map((n, i) => { const [x, y] = pos(n.a, n.r); return <Pop key={'h' + i} x={x + 70} y={y - 70} at={n.at + 0.3} float={5}><Icon name="heart" size={64} /></Pop>; })}
      {ring2.map((n, i) => { const [x, y] = pos(n.a, n.r); return <Pop key={'b' + i} x={x} y={y} at={n.at}><Icon name="person" size={110} color={['#D49A6A', '#B9774A', '#E7B98C'][i % 3]} /></Pop>; })}
    </>
  );
};

/** ক্রেতা বাড়ার বার চার্ট + ক্যালেন্ডার (টেক্সট ছাড়া) */
export const Growth: React.FC = () => {
  const f = useCurrentFrame();
  const hs = [140, 220, 320, 430, 560, 700, 860];
  return (
    <>
      <MGBg />
      <Pop x={300} y={330} at={0}><Icon name="calendar" size={260} /></Pop>
      <Pop x={780} y={330} at={0.2}><Icon name="clock" size={220} /></Pop>
      <svg viewBox="0 0 1080 1920" width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
        <line x1={80} y1={1500} x2={1000} y2={1500} stroke={C.ink} strokeWidth={8} strokeLinecap="round" />
        {hs.map((h, i) => {
          const k = interpolate(f, [i * 7 + 6, i * 7 + 26], [0, 1], clamp);
          return <rect key={i} x={110 + i * 125} y={1500 - h * k} width={90} height={h * k} rx={10} fill={['#7CC576', '#6CC24A', '#4CAF6A'][i % 3]} stroke={C.ink} strokeWidth={5} />;
        })}
      </svg>
      {hs.map((h, i) => {
        const k = interpolate(f, [i * 7 + 6, i * 7 + 26], [0, 1], clamp);
        return k > 0.9 ? <Pop key={i} x={155 + i * 125} y={1440 - h} at={(i * 7 + 24) / 30}><Icon name="person" size={90} /></Pop> : null;
      })}
    </>
  );
};

/** শুধু ক্যালেন্ডার + ঘড়ি — সময় কাটছে (২ বছর) */
export const TimePass: React.FC = () => (
  <>
    <MGBg />
    <Pop x={540} y={760} at={0}><Icon name="calendar" size={520} /></Pop>
    <Pop x={820} y={1220} at={0.3}><Icon name="clock" size={300} /></Pop>
    <Pop x={260} y={1240} at={0.5}><Icon name="tin" size={260} /></Pop>
  </>
);

/** শেষ শিক্ষা — কোটেশন কার্ড */
export const QuoteCard: React.FC = () => {
  const t = useSec();
  const k2 = Math.max(0, Math.min(1, (t - 2.55) / 0.4));
  return (
    <>
      <MGBg tone="dark" />
      <Pop x={540} y={560} at={0.2} float={8}><Icon name="paperfold" size={300} /></Pop>
      <Pop x={540} y={900} at={0.4}>
        <div style={{width: 900, textAlign: 'center', fontFamily, fontWeight: 700, fontSize: 84, lineHeight: 1.3, color: '#fff'}}>
          কিছু <span style={{color: C.yellow}}>অপমান</span> ফেলে দিতে হয় না।
        </div>
      </Pop>
      <div style={{position: 'absolute', left: 90, width: 900, top: 1090, opacity: k2, transform: `translateY(${(1 - k2) * 30}px)`, textAlign: 'center', fontFamily, fontWeight: 600, fontSize: 62, lineHeight: 1.4, color: '#E8ECF8'}}>
        সেগুলো <span style={{color: C.yellow, fontWeight: 700}}>পকেটে</span> রেখে দিলে, প্রতিদিন সকালে বিছানা ছেড়ে ওঠার <span style={{color: C.yellow, fontWeight: 700}}>কারণ</span> হয়ে যায়।
      </div>
      <Pop x={540} y={1560} at={2.9} float={6}><Icon name="sun" size={200} /></Pop>
    </>
  );
};
