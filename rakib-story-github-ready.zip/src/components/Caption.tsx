import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {CAPTIONS} from '../data/captions';
import {TEXT_WINDOWS} from '../timeline';
import {C, fontFamily} from '../theme';

const KEYS = ['রিকশা', 'দশটা', 'টাকা', 'বেতনের', 'খামটা', 'মায়ের', 'স্বপ্ন', 'খাতার', 'ব্যাংক', 'জামানত', 'ফাহিম', 'পাঁচশো', 'কৌটা', 'ফেসবুক', 'পেজ', 'অর্ডার', 'কুড়িটা', 'কুরিয়ার', 'ফোন', 'ফেরত', 'ক্ষমা', 'কিস্তি', 'সাইকেল', 'চিরকুট', 'অফিস', 'দশজন', 'কাগজ', 'পকেট', 'অপমান', 'পঁয়ষট্টি', 'হাজার', 'দুই', 'পাঁচ', 'ভাঙা', 'এক সপ্তাহ', 'সপ্তাহ', 'খবরের', 'ড্রয়ার', 'বছর'];
const isKey = (w: string) => KEYS.some((k) => w.replace(/[।,?!]/g, '').startsWith(k));

/** নিচের ক্যাপশন: ভাসমান ওভারলে। বাবল/কার্ড/স্ট্যাম্প চললে দেখায় না। */
export const Caption: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = f / fps;
  if (TEXT_WINDOWS.some(([a, b]) => t >= a && t < b)) return null;
  const cue = CAPTIONS.find((c) => t >= c.s && t < c.e);
  if (!cue) return null;
  const sp = spring({frame: f - Math.round(cue.s * fps), fps, config: {damping: 14, stiffness: 180, mass: 0.6}});
  const words = cue.t.split(' ');
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 170, display: 'flex', justifyContent: 'center', opacity: Math.min(1, sp), transform: `translateY(${(1 - sp) * 30}px)`}}>
      <div style={{background: 'rgba(20,20,28,.8)', borderRadius: 44, padding: '16px 40px', fontFamily, fontWeight: 700, fontSize: cue.t.length > 26 ? 46 : 54, color: '#fff', whiteSpace: 'nowrap', boxShadow: '0 6px 18px rgba(0,0,0,.35)'}}>
        {words.map((w, i) => <span key={i} style={{color: isKey(w) ? C.yellow : '#fff'}}>{w}{i < words.length - 1 ? ' ' : ''}</span>)}
      </div>
    </div>
  );
};
