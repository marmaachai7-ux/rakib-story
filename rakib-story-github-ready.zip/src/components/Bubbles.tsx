import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {At, clamp} from '../lib/At';
import {C, fmt, fontFamily} from '../theme';
import {Icon} from './Icons';

const useSp = (delay = 0, damping = 12, stiffness = 200) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: f - delay, fps, config: {damping, stiffness, mass: 0.5}});
};
const bd = `5px solid ${C.ink}`;

const SpeechIn: React.FC<{cx: number; bottom: number; w: number; tx: number; text: string; sz: number}> = ({cx, bottom, w, tx, text, sz}) => {
  const sp = useSp();
  return (
    <div style={{position: 'absolute', left: cx - w / 2, bottom: 1920 - bottom, width: w, transformOrigin: `${w / 2 + tx}px 100%`, transform: `scale(${sp})`}}>
      <div style={{background: '#fff', border: bd, borderRadius: 46, padding: '26px 36px', fontFamily, fontWeight: 700, fontSize: sz, lineHeight: 1.35, textAlign: 'center', color: C.ink}}>{text}</div>
      <div style={{position: 'absolute', left: w / 2 + tx - 20, bottom: -22, width: 40, height: 40, background: '#fff', borderRight: bd, borderBottom: bd, transform: 'rotate(45deg)', borderBottomRightRadius: 8}} />
    </div>
  );
};
/** স্পিচ কলআউট বাবল: cx = বাবলের কেন্দ্র x, bottom = বাবলের নিচের কিনারা y, tx = লেজের অবস্থান (কেন্দ্র থেকে) */
export const Speech: React.FC<{cx: number; bottom: number; text: string; at: readonly [number, number] | number[]; w?: number; tx?: number; sz?: number}> = ({cx, bottom, text, at, w = 840, tx = 0, sz = 56}) => (
  <At from={at[0]} to={at[1]} fade={false}><SpeechIn cx={cx} bottom={bottom} w={w} tx={tx} text={text} sz={sz} /></At>
);

const PillIn: React.FC<{text: string; cx: number; top: number; color: string; size: number}> = ({text, cx, top, color, size}) => {
  const sp = useSp();
  return (
    <div style={{position: 'absolute', left: cx, top, transform: `translate(-50%,0) translateY(${(1 - sp) * -50}px) scale(${sp})`, background: color, border: `4px solid ${C.ink}`, borderRadius: 60, padding: '10px 36px', fontFamily, fontWeight: 700, fontSize: size, color: C.ink, whiteSpace: 'nowrap'}}>{text}</div>
  );
};
/** পরিচয় / সময় পিল-ব্যাজ (ভাসমান ওভারলে) */
export const Badge: React.FC<{text: string; cx: number; top: number; at: readonly [number, number] | number[]; color?: string; size?: number}> = ({text, cx, top, at, color = C.yellow, size = 48}) => (
  <At from={at[0]} to={at[1]} fade={false}><PillIn text={text} cx={cx} top={top} color={color} size={size} /></At>
);

const StampIn: React.FC<{text: string; cx: number; cy: number; color: string}> = ({text, cx, cy, color}) => {
  const f = useCurrentFrame();
  const k = interpolate(f, [0, 6], [2.6, 1], clamp);
  const sh = f > 5 && f < 12 ? Math.sin(f * 3) * 6 : 0;
  return (
    <div style={{position: 'absolute', left: cx, top: cy, opacity: interpolate(f, [0, 3], [0, 1], clamp), transform: `translate(-50%,-50%) translateX(${sh}px) rotate(-8deg) scale(${k})`, border: `12px solid ${color}`, borderRadius: 26, padding: '14px 50px', fontFamily, fontWeight: 700, fontSize: 130, color, background: 'rgba(255,255,255,.88)', whiteSpace: 'nowrap'}}>{text}</div>
  );
};
/** বোল্ড স্ট্যাম্প */
export const Stamp: React.FC<{text: string; cx: number; cy: number; at: readonly [number, number] | number[]; color?: string}> = ({text, cx, cy, at, color = C.red}) => (
  <At from={at[0]} to={at[1]} fade={false}><StampIn text={text} cx={cx} cy={cy} color={color} /></At>
);

const NoteIn: React.FC<{cx: number; top: number; children: React.ReactNode}> = ({cx, top, children}) => {
  const sp = useSp(0, 11, 170);
  return (
    <div style={{position: 'absolute', left: cx, top, transform: `translate(-50%,0) rotate(3deg) scale(${sp})`, background: '#FFE98A', border: bd, borderRadius: 14, padding: '34px 50px 24px', fontFamily, fontWeight: 700, fontSize: 72, color: C.ink, textAlign: 'center', boxShadow: '8px 10px 0 rgba(0,0,0,.18)'}}>
      <div style={{position: 'absolute', left: '50%', top: -22, width: 36, height: 36, borderRadius: 18, background: C.red, border: `4px solid ${C.ink}`, transform: 'translateX(-50%)'}} />
      {children}
    </div>
  );
};
/** পিন করা নোট কার্ড */
export const NoteCard: React.FC<{cx: number; top: number; at: readonly [number, number] | number[]; children: React.ReactNode}> = ({cx, top, at, children}) => (
  <At from={at[0]} to={at[1]} fade={false}><NoteIn cx={cx} top={top}>{children}</NoteIn></At>
);

/** সংখ্যা গুনে ওঠা (কার্ডের লোকাল টাইমে) */
export const Count: React.FC<{from?: number; to: number; dur?: number; fmtFn?: (n: number) => string}> = ({from = 0, to, dur = 1.2, fmtFn = fmt}) => {
  const f = useCurrentFrame();
  return <>{fmtFn(interpolate(f, [0, dur * 30], [from, to], clamp))}</>;
};

const BigIn: React.FC<{cx: number; cy: number}> = ({cx, cy}) => {
  const sp = useSp(0, 10, 150);
  return (
    <div style={{position: 'absolute', left: cx, top: cy, transform: `translate(-50%,-50%) scale(${sp})`, background: '#fff', border: bd, borderRadius: 40, padding: '30px 60px', display: 'flex', alignItems: 'center', gap: 30, boxShadow: '10px 12px 0 rgba(0,0,0,.2)'}}>
      <Icon name="taka" size={170} />
      <div style={{fontFamily, fontWeight: 700, color: C.ink, lineHeight: 1.1}}>
        <div style={{fontSize: 130}}><Count to={65000} dur={1.6} /></div>
        <div style={{fontSize: 70, color: C.green}}>টাকা জমেছে</div>
      </div>
    </div>
  );
};
/** ৬৫,০০০ টাকার কাউন্টার কার্ড */
export const CounterCard: React.FC<{cx: number; cy: number; at: readonly [number, number] | number[]}> = ({cx, cy, at}) => (
  <At from={at[0]} to={at[1]} fade={false}><BigIn cx={cx} cy={cy} /></At>
);

const ProgIn: React.FC = () => {
  const f = useCurrentFrame();
  const sp = useSp();
  const p = interpolate(f, [10, 66], [0, 1], clamp);
  return (
    <div style={{position: 'absolute', left: 540, top: 250, width: 880, transform: `translate(-50%,0) scale(${sp})`, background: '#fff', border: bd, borderRadius: 36, padding: '26px 40px', fontFamily, fontWeight: 700, color: C.ink, boxShadow: '8px 10px 0 rgba(0,0,0,.18)'}}>
      <div style={{fontSize: 64, textAlign: 'center'}}>কিস্তিতে <span style={{color: C.red}}>টাকা ফেরত</span></div>
      <div style={{height: 44, borderRadius: 24, border: bd, background: '#eee', marginTop: 18, overflow: 'hidden'}}><div style={{width: `${p * 100}%`, height: '100%', background: C.green}} /></div>
      <div style={{textAlign: 'right', fontSize: 44, marginTop: 6}}>{Math.round(p * 100) === 0 ? '০%' : `${String(Math.round(p * 100)).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[+d])}%`}</div>
    </div>
  );
};
/** প্রগ্রেস বারসহ কার্ড */
export const ProgressCard: React.FC<{at: readonly [number, number] | number[]}> = ({at}) => (
  <At from={at[0]} to={at[1]} fade={false}><ProgIn /></At>
);
