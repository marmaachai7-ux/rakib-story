import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {DURATION, FPS, W, H} from './theme';

export const Root: React.FC = () => (
  <Composition id="RakibStory" component={Video} durationInFrames={DURATION} fps={FPS} width={W} height={H} />
);
