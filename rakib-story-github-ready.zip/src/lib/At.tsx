import React from 'react';
import {AbsoluteFill, Sequence, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FPS} from '../theme';

export const sec = (s: number) => Math.round(s * FPS);
export const useSec = () => useCurrentFrame() / FPS;
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export {clamp};

const FadeIn: React.FC<{children: React.ReactNode}> = ({children}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{opacity: interpolate(f, [0, 6], [0, 1], clamp)}}>{children}</AbsoluteFill>;
};

/** গ্লোবাল সেকেন্ডে from→to পর্যন্ত চলা Sequence. fade=true হলে ৬ ফ্রেম ক্রসফেড ওভারল্যাপ থাকে। */
export const At: React.FC<{from: number; to: number; fade?: boolean; children: React.ReactNode}> = ({from, to, fade = true, children}) => (
  <Sequence from={sec(from)} durationInFrames={Math.max(1, sec(to) - sec(from) + (fade ? 6 : 0))}>
    {fade ? <FadeIn>{children}</FadeIn> : <AbsoluteFill>{children}</AbsoluteFill>}
  </Sequence>
);

/** ক্যামেরা: হালকা জুম/প্যান + স্ক্রিন শেক */
export const Cam: React.FC<{z?: [number, number]; x?: [number, number]; y?: [number, number]; shake?: number; o?: string; children: React.ReactNode}> = ({
  z = [1, 1], x = [0, 0], y = [0, 0], shake = 0, o = '50% 50%', children,
}) => {
  const f = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const p = f / Math.max(1, durationInFrames);
  const sc = z[0] + (z[1] - z[0]) * p;
  const tx = x[0] + (x[1] - x[0]) * p + (shake ? Math.sin(f * 2.3) * shake : 0);
  const ty = y[0] + (y[1] - y[0]) * p + (shake ? Math.cos(f * 3.1) * shake : 0);
  return <AbsoluteFill style={{transform: `translate(${tx}px,${ty}px) scale(${sc})`, transformOrigin: o}}>{children}</AbsoluteFill>;
};

/** At + Cam একসাথে: একটি শট */
export const Shot: React.FC<{from: number; to: number; cam?: Omit<React.ComponentProps<typeof Cam>, 'children'>; children: React.ReactNode}> = ({from, to, cam, children}) => (
  <At from={from} to={to}>
    <Cam {...cam}>{children}</Cam>
  </At>
);

/** আইকন/এলিমেন্ট পপ-আপ: at সেকেন্ডে (শটের লোকাল টাইম) স্প্রিং দিয়ে আসে, চাইলে out-এ মিলিয়ে যায়। (x,y) = কেন্দ্র */
export const Pop: React.FC<{x: number; y: number; at?: number; out?: number; float?: number; rot?: number; pulse?: boolean; children: React.ReactNode}> = ({
  x, y, at = 0, out, float = 0, rot = 0, pulse = false, children,
}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sp = spring({frame: f - sec(at), fps, config: {damping: 10, stiffness: 150, mass: 0.6}});
  const fl = float ? Math.sin(f / 14) * float : 0;
  const pl = pulse ? 1 + Math.sin(f / 5) * 0.06 : 1;
  const op = f < sec(at) ? 0 : out !== undefined ? interpolate(f, [sec(out) - 6, sec(out)], [1, 0], clamp) : 1;
  return (
    <div style={{position: 'absolute', left: x, top: y, opacity: op, transform: `translate(-50%,-50%) translateY(${fl}px) scale(${sp * pl}) rotate(${rot}deg)`}}>
      {children}
    </div>
  );
};

/** শটের লোকাল সময়ে একটি এলিমেন্ট এক জায়গা থেকে আরেক জায়গায় যায় */
export const Move: React.FC<{from: [number, number]; to: [number, number]; t0: number; t1: number; scale?: [number, number]; hideAfter?: boolean; children: React.ReactNode}> = ({
  from, to, t0, t1, scale = [1, 1], hideAfter = false, children,
}) => {
  const t = useSec();
  const k = interpolate(t, [t0, t1], [0, 1], clamp);
  const x = from[0] + (to[0] - from[0]) * k;
  const y = from[1] + (to[1] - from[1]) * k;
  const s = scale[0] + (scale[1] - scale[0]) * k;
  return (
    <div style={{position: 'absolute', left: x, top: y, opacity: hideAfter && t >= t1 ? 0 : 1, transform: `translate(-50%,-50%) scale(${s})`}}>{children}</div>
  );
};
