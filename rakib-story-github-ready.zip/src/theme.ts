import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const {fontFamily} = loadFont('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const DURATION = 5185; // voice.mp3 = 172.826s
export const GROUND = 1560; // feet line for characters

export const C = {
  ink: '#222222', yellow: '#FFD23F', red: '#D64545', green: '#2E9E5B', blue: '#4A90D9',
  cream: '#FFF6E0', white: '#FFFFFF', navy: '#1B2547',
};

const D = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export const bn = (n: number | string) => String(n).replace(/\d/g, (d) => D[+d]);
export const fmt = (n: number) => bn(Math.round(n).toLocaleString('en-US'));
