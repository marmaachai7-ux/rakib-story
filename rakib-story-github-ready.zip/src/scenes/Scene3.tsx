import React from 'react';
import {Shot, Pop, Move, useSec} from '../lib/At';
import {Char, P} from '../components/Char';
import {BankBg, TeaBg, NightRoom, Table} from '../components/Backgrounds';
import {HandIcon, Icon} from '../components/Icons';
import {Speech, Stamp, CounterCard} from '../components/Bubbles';
import {TimePass} from '../components/MG';
import {GROUND as G} from '../theme';
import {T} from '../timeline';

const Banks: React.FC<{cross?: boolean}> = ({cross}) => (
  <>
    {[270, 540, 810].map((x, i) => (
      <React.Fragment key={x}>
        <Pop x={x} y={250} at={cross ? 0 : 1.0 + i * 0.9}><Icon name="bank" size={170} /></Pop>
        {cross && <Pop x={x + 50} y={300} at={0.3 + i * 0.5}><Icon name="cross" size={90} /></Pop>}
      </React.Fragment>
    ))}
  </>
);

const CupHand: React.FC = () => {
  const t = useSec();
  return (
    <>
      <Char who="rakib" x={260} y={G} mood="sad" talk={[[0, 1.8]]} />
      <Char who="fahim" x={820} y={G} mood="neutral" moods={[{t: 2.0, m: 'surprised'}]} pose={{l: 55, r: -7}} lHand={t < 2.2 ? <HandIcon name="cup" size={46} /> : undefined} seed={5} />
    </>
  );
};

const Saving: React.FC = () => (
  <>
    <Char who="rakib" x={300} y={G} mood="determined" pose={P.give} rHand={<HandIcon name="envelope" size={46} />} />
    <Table x={520} w={540} />
    <Pop x={790} y={1180} at={0}><Icon name="tin" size={260} /></Pop>
    <Move from={[330, 960]} to={[790, 1120]} t0={2.0} t1={3.2} scale={[0.4, 0.5]} hideAfter><Icon name="note" size={200} label="৫০০" /></Move>
  </>
);

export const Scene3: React.FC = () => (
  <>
    <Shot from={43.3} to={47.06}>
      <BankBg />
      <Char who="rakib" y={G} s={2.0} mood="neutral" walk={{x0: 100, x1: 330, t0: 0.3, t1: 1.8}} />
      <Banks />
    </Shot>
    <Shot from={47.06} to={51.0}>
      <BankBg />
      <Char who="rakib" y={G} s={2.0} mood="sad" walk={{x0: 330, x1: -250, t0: 1.2, t1: 3.6}} />
      <Banks cross />
    </Shot>
    <Stamp text="জামানত নেই" cx={540} cy={1000} at={T.stampNo} />
    <Shot from={51.0} to={54.46}>
      <TeaBg />
      <CupHand />
    </Shot>
    <Shot from={54.46} to={58.4} cam={{z: [1, 1.08], o: '75% 50%'}}>
      <TeaBg />
      <Char who="rakib" x={260} y={G} mood="sad" moods={[{t: 2.6, m: 'think'}]} look={4} />
      <Char who="fahim" x={820} y={G} mood="happy" pose={P.up} look={-4} talk={[[0.1, 3.8]]} seed={5} />
      <Pop x={260} y={620} at={3.0} float={8}><Icon name="bulb" size={170} /></Pop>
    </Shot>
    <Speech cx={620} bottom={720} w={860} tx={200} text="ব্যাংক না দিলে নিজের টাকাতেই শুরু কর দোস্ত, ছোট করে হলেও।" at={T.fahim} />
    <Shot from={58.4} to={64.04}>
      <NightRoom />
      <Saving />
    </Shot>
    <Shot from={64.04} to={69.96}>
      <NightRoom />
      <Char who="rakib" x={300} y={G} mood="think" pose={{l: -30, r: -45}} rHand={<HandIcon name="phone" size={50} />} look={3} />
      <Char who="ma" x={880} y={G} s={1.5} mood="sleep" seed={2} />
      <Pop x={880} y={800} at={0.5} float={6}><Icon name="zzz" size={150} /></Pop>
      <Pop x={560} y={780} at={1.2} float={6}><Icon name="play" size={170} /></Pop>
      <Pop x={420} y={600} at={2.4} float={6}><Icon name="bag" size={140} /></Pop>
      <Pop x={640} y={520} at={3.6} float={6}><Icon name="taka" size={140} /></Pop>
    </Shot>
    <Shot from={69.96} to={72.0}>
      <TimePass />
    </Shot>
    <Shot from={72.0} to={74.4}>
      <NightRoom />
      <Char who="rakib" x={300} y={G} mood="happy" pose={P.up} moods={[{t: 0.3, m: 'happy'}]} />
      <Table x={520} w={540} />
      <Pop x={790} y={1160} at={0}><Icon name="tinopen" size={280} /></Pop>
    </Shot>
    <CounterCard cx={540} cy={700} at={T.sixtyFive} />
  </>
);
