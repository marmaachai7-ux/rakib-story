import React from 'react';
import {Shot, Pop} from '../lib/At';
import {Char, P} from '../components/Char';
import {OfficeBg, Desk} from '../components/Backgrounds';
import {Icon} from '../components/Icons';
import {Speech, Badge, NoteCard} from '../components/Bubbles';
import {QuoteCard} from '../components/MG';
import {GROUND as G} from '../theme';
import {T} from '../timeline';

const Team: React.FC = () => (
  <>
    {[0, 1].map((r) => [0, 1, 2, 3, 4].map((c) => (
      <Char key={`${r}${c}`} who={`e${r * 5 + c}`} x={140 + c * 200} y={1040 + r * 130} s={0.9 + r * 0.08} mood="happy" seed={r * 5 + c} />
    )))}
  </>
);
const Paper: React.FC = () => <Pop x={380} y={1290} at={0}><Icon name="paperfold" size={190} /></Pop>;

export const Scene6: React.FC = () => (
  <>
    <Shot from={140.2} to={143.72}>
      <OfficeBg />
      <Team />
      <Char who="rakib2" x={540} y={1880} s={1.9} mood="happy" pose={P.cross} />
    </Shot>
    <Badge text="৫ বছর পর" cx={540} top={140} at={[140.4, 143.7]} />
    <NoteCard cx={540} top={320} at={T.note10}>১০ জন <span style={{color: '#D64545'}}>কর্মচারী</span></NoteCard>
    <Shot from={143.72} to={147.96}>
      <OfficeBg />
      <Char who="rakib2" x={300} y={G} mood="happy" look={3} />
      <Char who="jamal" y={G} mood="neutral" look={-4} walk={{x0: 1300, x1: 800, t0: 0.4, t1: 2.4}} seed={3} />
      <Desk />
    </Shot>
    <Shot from={147.96} to={151.0}>
      <OfficeBg />
      <Char who="rakib2" x={300} y={G} mood="neutral" look={3} />
      <Char who="jamal" x={800} y={G} mood="worried" look={-4} talk={[[0, 3.0]]} seed={3} />
      <Desk />
    </Shot>
    <Speech cx={620} bottom={730} w={820} tx={180} text="রাকিব, তুমি এতদূর কীভাবে এলে?" at={T.jamalQ} />
    <Shot from={151.0} to={155.5} cam={{z: [1, 1.25], o: '30% 75%'}}>
      <OfficeBg />
      <Char who="rakib2" x={300} y={G} mood="neutral" pose={P.idle} poses={[{t: 0.8, p: {l: -10, r: 20}}, {t: 2.0, p: P.work}, {t: 3.0, p: P.idle}]} />
      <Char who="jamal" x={800} y={G} mood="think" look={-4} seed={3} />
      <Desk drawerAt={0.8} />
      <Pop x={380} y={1290} at={2.2}><Icon name="paperfold" size={190} /></Pop>
    </Shot>
    <Shot from={155.5} to={159.6}>
      <OfficeBg />
      <Char who="rakib2" x={300} y={G} mood="neutral" look={3} talk={[[0.1, 3.9]]} />
      <Char who="jamal" x={800} y={G} mood="think" look={-4} seed={3} />
      <Desk drawerAt={0} />
      <Paper />
    </Shot>
    <Speech cx={480} bottom={730} w={880} tx={-150} text="সেদিনের কথাটা আমি ফেলে দিইনি চাচা, পকেটে রেখে দিয়েছিলাম।" at={T.rakibQ} />
    <Shot from={159.6} to={165.5} cam={{z: [1, 1.45], o: '75% 60%'}}>
      <OfficeBg />
      <Char who="rakib2" x={300} y={G} mood="neutral" look={3} />
      <Char who="jamal" x={800} y={G} mood="think" moods={[{t: 3.0, m: 'sad'}]} look={-3} tremble={0.8} seed={3} />
      <Desk drawerAt={0} />
      <Paper />
      <Pop x={560} y={640} at={2.5} float={6}><Icon name="clock" size={160} /></Pop>
    </Shot>
    <Shot from={165.4} to={172.83}><QuoteCard /></Shot>
  </>
);
