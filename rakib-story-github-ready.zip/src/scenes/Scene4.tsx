import React from 'react';
import {Shot, Pop, Move} from '../lib/At';
import {Char, P} from '../components/Char';
import {WorkRoom, NightRoom, Table} from '../components/Backgrounds';
import {HandIcon, Icon} from '../components/Icons';
import {NoteCard, Count} from '../components/Bubbles';
import {bn, GROUND as G} from '../theme';
import {T} from '../timeline';

const bells = [[220, 560], [860, 520], [540, 420], [140, 900], [940, 880], [330, 760], [760, 740], [540, 640]];

export const Scene4: React.FC = () => (
  <>
    <Shot from={74.4} to={79.04}>
      <WorkRoom />
      <Char who="rakib" x={300} y={G} mood="happy" pose={P.hold} />
      <Pop x={600} y={900} at={0.3}><Icon name="box" size={200} /></Pop>
      <Pop x={600} y={640} at={1.1} float={6}><Icon name="spoon" size={190} /></Pop>
      <Pop x={800} y={760} at={2.3} float={6}><Icon name="knife" size={190} /></Pop>
      <Pop x={880} y={1000} at={3.4} float={6}><Icon name="pot" size={200} /></Pop>
    </Shot>
    <Shot from={79.04} to={85.1}>
      <WorkRoom />
      <Char who="rakib" x={300} y={G} mood="neutral" moods={[{t: 1.6, m: 'happy'}, {t: 3.8, m: 'sad'}]} />
      <Pop x={760} y={900} at={0.3} float={6}><Icon name="page" size={300} /></Pop>
      <Pop x={900} y={720} at={1.6} float={6}><Icon name="heart" size={100} /></Pop>
      <Pop x={720} y={1250} at={4.2}><Icon name="person" size={150} color="#C98BD1" /></Pop>
    </Shot>
    <NoteCard cx={540} top={240} at={T.order1}>১টি <span style={{color: '#D64545'}}>অর্ডার</span></NoteCard>
    <Shot from={85.1} to={88.56} cam={{shake: 3}}>
      <WorkRoom />
      <Char who="rakib" x={540} y={G} s={2.4} mood="surprised" pose={P.both} tremble={2} />
      {bells.map(([x, y], i) => <Pop key={i} x={x} y={y + 300} at={0.3 + i * 0.3} float={6}><Icon name="bell" size={120} /></Pop>)}
    </Shot>
    <NoteCard cx={540} top={240} at={T.order20}><Count from={1} to={20} dur={1.2} fmtFn={(n) => bn(Math.round(n))} />টি <span style={{color: '#D64545'}}>অর্ডার</span></NoteCard>
    <Shot from={88.56} to={93.74}>
      <WorkRoom />
      <Char who="rakib" x={300} y={G} mood="happy" pose={P.give} rHand={<HandIcon name="taka" size={40} />} />
      <Table x={560} w={480} />
      <Pop x={800} y={1180} at={0}><Icon name="tinopen" size={220} /></Pop>
      {[0, 1, 2].map((i) => <Pop key={i} x={760 + i * 80} y={1060 - i * 20} at={1.0 + i * 0.7}><Icon name="box" size={150} /></Pop>)}
      <Move from={[-200, 1500]} to={[1300, 1500]} t0={3.4} t1={5.0}><Icon name="van" size={320} /></Move>
    </Shot>
    <Shot from={93.74} to={99.9} cam={{shake: 3}}>
      <WorkRoom />
      <Char who="rakib" x={540} y={G} mood="worried" tremble={1.5} />
      <Pop x={840} y={600} at={0.2}><Icon name="phone" size={240} label="ring" /></Pop>
      <Pop x={240} y={600} at={2.0}><Icon name="broken" size={230} /></Pop>
      <Pop x={540} y={430} at={3.8}><Icon name="calendar" size={210} /></Pop>
      <Pop x={840} y={380} at={5.4}><Icon name="refund" size={200} /></Pop>
    </Shot>
    <Shot from={99.9} to={105.78} cam={{z: [1, 1.12], o: '50% 70%'}}>
      <NightRoom />
      <Char who="rakib" x={540} y={G} mood="cry" sit tremble={1} />
      <Pop x={130} y={1640} at={0.8}><Icon name="tinopen" size={230} /></Pop>
    </Shot>
    <Shot from={105.78} to={108.7}>
      <NightRoom />
      <Char who="rakib" x={330} y={G} mood="cry" sit />
      <Char who="ma" y={G} mood="happy" walk={{x0: 1300, x1: 830, t0: 0, t1: 1.4}} pose={P.give} rHand={<HandIcon name="plate" size={50} />} seed={2} />
      <Pop x={640} y={1700} at={2.0}><Icon name="plate" size={200} /></Pop>
      <Pop x={830} y={620} at={2.2} float={6}><Icon name="heart" size={120} /></Pop>
    </Shot>
  </>
);
