import React from 'react';
import {Shot, Pop} from '../lib/At';
import {Char, P} from '../components/Char';
import {ShopBg, WorkRoom, NightRoom, Table} from '../components/Backgrounds';
import {HandIcon, Icon} from '../components/Icons';
import {Speech} from '../components/Bubbles';
import {useSec} from '../lib/At';
import {GROUND as G} from '../theme';
import {T} from '../timeline';

const Hand: React.FC = () => <HandIcon name="envelope" size={46} />;

/** খাম হাত বদল: ১.৫ সেকেন্ডে রাকিবের হাত থেকে মায়ের হাতে */
const Handover: React.FC = () => {
  const t = useSec();
  return (
    <>
      <Char who="rakib" x={250} y={G} mood="happy" pose={P.give} rHand={t < 1.5 ? <Hand /> : undefined} />
      <Char who="ma" x={830} y={G} mood="happy" pose={P.take} lHand={t >= 1.5 ? <Hand /> : undefined} seed={2} />
    </>
  );
};

export const Scene2: React.FC = () => (
  <>
    <Shot from={21.66} to={25.3}>
      <ShopBg />
      <Char who="rakib" x={540} y={G} mood="neutral" pose={P.work} poses={[{t: 0.9, p: {l: -12, r: 12}}, {t: 1.8, p: P.work}, {t: 2.7, p: {l: -12, r: 12}}]} />
      <Table x={160} w={760} top={1330} color="#9A6B47" />
      <Pop x={540} y={1250} at={0.4}><Icon name="cloth" size={170} /></Pop>
    </Shot>
    <Shot from={25.3} to={33.02}>
      <WorkRoom />
      <Handover />
      <Pop x={640} y={560} at={2.1} float={6}><Icon name="basket" size={190} /></Pop>
      <Pop x={850} y={540} at={3.1} float={6}><Icon name="pill" size={170} /></Pop>
      <Pop x={540} y={420} at={4.3} float={6}><Icon name="house" size={210} /></Pop>
      <Pop x={540} y={1180} at={5.9} float={5}><Icon name="plate" size={200} /></Pop>
    </Shot>
    <Shot from={33.02} to={39.66}>
      <NightRoom />
      <Char who="rakib" x={300} y={G} mood="neutral" pose={P.work} moods={[{t: 0.8, m: 'think'}]} look={0} />
      <Char who="ma" y={G} mood="neutral" walk={{x0: 1300, x1: 830, t0: 3.0, t1: 4.5}} moods={[{t: 4.5, m: 'surprised'}]} seed={2} />
      <Table x={30} w={640} />
      <Pop x={300} y={1250} at={0.3}><Icon name="notebook" size={190} /></Pop>
      <Pop x={300} y={600} at={0.8} float={8}><Icon name="bulb" size={190} /></Pop>
      <Pop x={830} y={620} at={5.5} float={6}><Icon name="heart" size={110} /></Pop>
    </Shot>
    <Shot from={39.66} to={43.3} cam={{z: [1, 1.08], o: '70% 50%'}}>
      <NightRoom />
      <Char who="rakib" x={300} y={G} mood="surprised" moods={[{t: 1.8, m: 'happy'}]} look={4} />
      <Char who="ma" x={800} y={G} mood="happy" look={-4} talk={[[0.1, 3.4]]} seed={2} />
      <Pop x={300} y={640} at={2.0} float={6}><Icon name="heart" size={130} /></Pop>
    </Shot>
    <Speech cx={620} bottom={700} w={860} tx={180} text="লিখে যখন রেখেছিস বাবা, করে দেখাতেও হবে।" at={T.ma} />
  </>
);
