import React from 'react';
import {Shot, Pop} from '../lib/At';
import {Char, P} from '../components/Char';
import {WorkRoom} from '../components/Backgrounds';
import {HandIcon, Icon} from '../components/Icons';
import {ProgressCard} from '../components/Bubbles';
import {Flow, Network, Growth} from '../components/MG';
import {GROUND as G} from '../theme';
import {T} from '../timeline';

export const Scene5: React.FC = () => (
  <>
    <Shot from={108.7} to={111.44}>
      <WorkRoom />
      <Char who="rakib" x={300} y={G} mood="determined" pose={P.hold} look={3} />
      <Pop x={760} y={760} at={0.2} pulse><Icon name="page" size={300} /></Pop>
      <Pop x={900} y={560} at={1.0}><Icon name="check" size={120} /></Pop>
      <Pop x={560} y={420} at={0.1}><Icon name="sun" size={200} /></Pop>
    </Shot>
    <Shot from={111.44} to={116.64}>
      <WorkRoom />
      <Char who="rakib" x={300} y={G} mood="sad" pose={{l: -30, r: -45}} rHand={<HandIcon name="phone" size={50} />} talk={[[0, 5.0]]} />
      {[0, 1, 2].map((i) => <Pop key={i} x={820} y={600 + i * 270} at={0.8 + i * 1.5} float={5}><Icon name="person" size={160} color={['#E7B98C', '#C58A5E', '#D49A6A'][i]} /></Pop>)}
    </Shot>
    <Shot from={116.64} to={121.6}>
      <WorkRoom />
      <Char who="rakib" x={300} y={G} mood="sad" pose={P.give} rHand={<HandIcon name="note" size={46} />} moods={[{t: 2.0, m: 'determined'}]} />
      <Pop x={820} y={1000} at={0.6}><Icon name="person" size={200} /></Pop>
      <Pop x={780} y={800} at={3.0}>
        <div style={{position: 'relative', width: 300, height: 300}}><Icon name="van" size={300} /><div style={{position: 'absolute', right: -10, top: -30}}><Icon name="cross" size={130} /></div></div>
      </Pop>
    </Shot>
    <ProgressCard at={T.kisti} />
    <Shot from={121.6} to={130.6}>
      <Flow title="নিজের হাতে ডেলিভারি" steps={[
        {icon: 'news', label: 'খবরের কাগজে মোড়া', at: 0.4},
        {icon: 'paper', label: 'হাতে লেখা চিরকুট', at: 3.6},
        {icon: 'bike', label: 'সাইকেলে পৌঁছে দেওয়া', at: 5.4},
      ]} />
    </Shot>
    <Shot from={130.6} to={137.04}><Network /></Shot>
    <Shot from={137.04} to={140.2}><Growth /></Shot>
  </>
);
