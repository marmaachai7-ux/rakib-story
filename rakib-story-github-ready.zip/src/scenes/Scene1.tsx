import React from 'react';
import {Shot, Pop, useSec, clamp} from '../lib/At';
import {interpolate} from 'remotion';
import {Char, P} from '../components/Char';
import {LivingRoom, StreetBg} from '../components/Backgrounds';
import {Icon} from '../components/Icons';
import {Speech} from '../components/Bubbles';
import {GROUND as G} from '../theme';
import {T} from '../timeline';

/** শার্টের পকেটে ঢোকা কাগজ: খোলা → ভাঁজ → পকেটে */
const PocketPaper: React.FC = () => {
  const t = useSec();
  const x = interpolate(t, [0, 1.9, 2.6], [541, 541, 593], clamp);
  const y = interpolate(t, [0, 1.9, 2.6], [1160, 1160, 1025], clamp);
  const size = interpolate(t, [0, 1.2, 1.4, 1.9, 2.6], [300, 300, 170, 170, 50], clamp);
  return (
    <div style={{position: 'absolute', left: x, top: y, opacity: t < 2.6 ? 1 : 0, transform: 'translate(-50%,-50%)'}}>
      <Icon name={t < 1.3 ? 'paper' : 'paperfold'} size={size} />
    </div>
  );
};

export const Scene1: React.FC = () => (
  <>
    <Shot from={0} to={4.32}>
      <LivingRoom />
      <Char who="rakib" x={300} y={G} mood="sad" look={4} />
      <Char who="jamal" x={780} y={G} mood="angry" look={-4} pose={P.pointL} talk={[[0.22, 4.2]]} seed={3} />
    </Shot>
    <Shot from={4.32} to={6.28} cam={{z: [1, 1.12], o: '72% 55%', shake: 3}}>
      <LivingRoom />
      <Char who="rakib" x={300} y={G} mood="sad" look={4} tremble={1} />
      <Char who="jamal" x={780} y={G} mood="angry" look={-4} pose={P.pointL} talk={[[0, 1.9]]} tremble={2} seed={3} />
    </Shot>
    <Speech cx={600} bottom={730} w={860} tx={180} text="নিজের সংসারই চালাতে পারো না, আবার এসেছ ব্যবসা করতে?" at={T.jamal1} />
    <Speech cx={620} bottom={730} w={760} tx={160} text="আগে নিজের অবস্থাটা দেখো।" at={T.jamal2} />

    <Shot from={6.28} to={9.02} cam={{z: [1, 1.35], o: '50% 40%'}}>
      <LivingRoom />
      <Char who="rakib" x={540} y={G} s={2.6} moods={[{t: 0, m: 'neutral'}, {t: 1, m: 'sad'}]} />
    </Shot>
    <Shot from={9.02} to={12.68}>
      <LivingRoom />
      <Char who="rakib" x={540} y={G} s={2.4} mood="neutral" pose={P.hold} poses={[{t: 2.0, p: {l: -32, r: 6}}]} pocketPaperAt={2.6} />
      <PocketPaper />
    </Shot>
    <Shot from={12.68} to={15.98}>
      <LivingRoom />
      <Char who="rakib" x={330} y={G} mood="sad" pose={P.salute} poses={[{t: 1.2, p: P.idle}]} walk={{x0: 330, x1: -300, t0: 1.6, t1: 3.1}} />
      <Char who="jamal" x={780} y={G} mood="neutral" look={-4} pose={P.cross} seed={3} />
    </Shot>
    <Shot from={15.98} to={21.66}>
      <StreetBg />
      <Char who="rakib" y={G} s={2.2} mood="worried" walk={{x0: -150, x1: 1230, t0: 0, t1: 5.6}} />
      <Pop x={540} y={620} at={2.0} float={8}>
        <div style={{position: 'relative', width: 280, height: 280}}>
          <Icon name="note" size={280} />
          <div style={{position: 'absolute', right: -20, bottom: -30}}><Icon name="cross" size={150} /></div>
        </div>
      </Pop>
    </Shot>
  </>
);
