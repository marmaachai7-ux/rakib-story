# Rakib Story Video (Remotion)
1080x1920 · 30fps · 5185 frames (voice.mp3 = 172.8s)

    npm install
    npx remotion studio
    npx remotion render RakibStory out/rakib-story.mp4

সময় বদলাতে: src/timeline.ts (বাবল/কার্ড/ক্যাপশন-সাপ্রেশন) · ক্যাপশন: src/data/captions.ts · সিন: src/scenes/
